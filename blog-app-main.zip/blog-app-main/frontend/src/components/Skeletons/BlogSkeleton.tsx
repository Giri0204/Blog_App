const BlogSkeleton = () => {
  return (
    <div>BlogSkeleton</div>
  )
}

export default BlogSkeleton